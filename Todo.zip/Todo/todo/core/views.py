from django.shortcuts import render,redirect
from .models import Todo

def home(request):
    search=request.GET.get('search')
    if search:
        todos = Todo.objects.filter(title__icontains=search)
    else:
        todos=Todo.objects.all()

    if request.method == 'POST':
        data=request.POST
        title=data.get('title')
        Todo.objects.create(title=title)
        return redirect('home')
    return render(request,'home.html',{'todos':todos})

def update(request,todo_id):
    todo=Todo.objects.get(id=todo_id)
    if request.method == 'POST':
        title=request.POST.get('title')
        todo.title=title
        todo.save()
        return redirect('home')
    return render(request,'update.html',{'todo':todo})

def delete(request,todo_id):
    Todo.objects.get(id=todo_id).delete()
    return redirect('home')